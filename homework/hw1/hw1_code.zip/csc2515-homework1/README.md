# CSC 2515 Homework 1

## Collaborators

Zhimao Lin, Bingzhang Zhu

## How to run the code

1. Install all packages by running `pip3 install -r requirements.txt`
2. Make sure the data is in the `data` folder of the current directory
   - The program assumes the data is in `./data/clean_real.txt` and `./data/clean_fake.txt`
3. Run `python3 ./hw1_code.py`

## References

- https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.CountVectorizer.html 

- https://towardsdatascience.com/basics-of-countvectorizer-e26677900f9c 

- https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.iloc.html 

- https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html 

- https://mljar.com/blog/visualize-decision-tree/ 

- https://towardsdatascience.com/visualizing-decision-trees-with-python-scikit-learn-graphviz-matplotlib-1c50b4aa68dc

- https://stackoverflow.com/questions/39476020/get-feature-and-class-names-into-decision-tree-using-export-graphviz

- https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html

- https://towardsdatascience.com/building-a-k-nearest-neighbors-k-nn-model-with-scikit-learn-51209555453a 

- https://stackoverflow.com/questions/69326639/sklearn-warnings-in-version-1-0 
