'''
CSC 2515 Homework 1 Code

Collaborators: Zhimao Lin Bingzhang Zhu
'''

import pandas as pd
import numpy as np
import math
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn import tree
from sklearn.neighbors import KNeighborsClassifier



###################
# Global Variables
###################
# Data
REAL_DATA_PATH = "./data/clean_real.txt"
FAKE_DATA_PATH = "./data/clean_fake.txt"

TRAIN_INPUT_DATA = None 
TRAIN_TARGET_DATA = None 
VALID_INPUT_DATA = None 
VALID_TARGET_DATA = None 
TEST_INPUT_DATA = None 
TEST_TARGET_DATA = None 

FEATURE_NAME = None

# Decision Tree
DT_CRITERION_LIST = ["gini", "entropy"]
DT_MAX_DEPTH_LIST = range(2, 8)
BEST_TREE = None

# KNN
KNN_K = range(1, 21)
BEST_KNN = None


def load_data(binary = False):
    real_data = pd.read_csv(REAL_DATA_PATH, header=None, names=["title"])
    real_data["class_label"] = "real"
    fake_data = pd.read_csv(FAKE_DATA_PATH, header=None, names=["title"])
    fake_data["class_label"] = "fake"
    data = pd.concat([real_data, fake_data], ignore_index=True)

    vectorizer = CountVectorizer(binary=binary)
    token_data = vectorizer.fit_transform(data["title"])
    token_data = pd.DataFrame(data=token_data.toarray(), columns=vectorizer.get_feature_names_out())
    data = pd.concat([data, token_data], axis=1)

    global FEATURE_NAME
    FEATURE_NAME = vectorizer.get_feature_names_out()

    input_data = data.iloc[:,2:]
    target_data = data.iloc[:,1:2]

    train_input_data, test_valid_input_data, train_target_data, test_valid_target_data = train_test_split(input_data, target_data, train_size=0.7, test_size=0.3, shuffle=True, random_state=1)

    valid_input_data, test_input_data, valid_target_data, test_target_data =  train_test_split(test_valid_input_data, test_valid_target_data, train_size=0.5, test_size=0.5, shuffle=True, random_state=1)

    print("Total data shape")
    print(data.shape)
    
    return train_input_data, train_target_data, valid_input_data, valid_target_data, test_input_data, test_target_data

def select_tree_model():
    candidate_list = []
    accuracy_list = []

    for criterion in DT_CRITERION_LIST:
        for max_depth in DT_MAX_DEPTH_LIST:
            clf = tree.DecisionTreeClassifier(criterion=criterion, max_depth=max_depth, random_state=0)
            clf.fit(TRAIN_INPUT_DATA, TRAIN_TARGET_DATA)
            accuracy = clf.score(VALID_INPUT_DATA, VALID_TARGET_DATA)
            accuracy_list.append(accuracy)
            candidate_list.append(clf)
            
            print(f"The mean accuracy of criterion=[{clf.get_params()['criterion']}] and max_depth=[{clf.get_depth()}] is [{accuracy}]" )

    best_tree = candidate_list[accuracy_list.index(max(accuracy_list))]

    print(f"Best model is criterion=[{best_tree.get_params()['criterion']}] and max_depth=[{best_tree.get_depth()}] with mean accuracy of [{max(accuracy_list)}]")


    accuracy = best_tree.score(TEST_INPUT_DATA, TEST_TARGET_DATA)
    print(f"The accuracy of the best model on the test set is [{accuracy}]")

    plt.figure()
    tree.plot_tree(best_tree, feature_names=FEATURE_NAME, class_names=best_tree.classes_, max_depth=2, filled=True)   
    plt.savefig("Question_C_Decision_Tree.png", bbox_inches="tight", dpi=300, transparent=False)
    plt.show()

    return best_tree

def get_entropy(p0, p1):
    return - p0 * math.log2(p0) - p1 * math.log2(p1)

def compute_information_gain(split_word):
    # Entropy before split
    train_data = pd.concat([TRAIN_INPUT_DATA, TRAIN_TARGET_DATA], axis=1)

    p_real = len(train_data[train_data["class_label"]=="real"])/len(train_data)
    p_fake = len(train_data[train_data["class_label"]=="fake"])/len(train_data)

    entropy_before_split = get_entropy(p_fake, p_real)

    # Entropy after split
    word_exists = train_data[train_data[split_word]!=0]
    word_not_exists = train_data[train_data[split_word]==0]

    p_exists = len(word_exists)/len(train_data)
    p_not_exists = len(word_not_exists)/len(train_data)

    p_real_given_exists = len(word_exists[word_exists["class_label"]=="real"])/len(word_exists)
    p_fake_given_exists = len(word_exists[word_exists["class_label"]=="fake"])/len(word_exists)
    p_real_given_not_exists = len(word_not_exists[word_not_exists["class_label"]=="real"])/len(word_not_exists)
    p_fake_given_not_exists = len(word_not_exists[word_not_exists["class_label"]=="fake"])/len(word_not_exists)

    entropy_given_exists = get_entropy(p_fake_given_exists, p_real_given_exists)
    entropy_given_not_exists = get_entropy(p_fake_given_not_exists, p_real_given_not_exists)

    entropy_after_split = entropy_given_exists * p_exists + entropy_given_not_exists * p_not_exists

    # Calculate the information gain
    return entropy_before_split - entropy_after_split
    


def select_knn_model():
    accuracy_list = []
    candidate_list = []

    train_error_list = []
    validation_error_list = []

    for k in KNN_K:
        knn = KNeighborsClassifier(n_neighbors=k)
        knn.fit(TRAIN_INPUT_DATA.values, TRAIN_TARGET_DATA.values.ravel())

        train_accuracy = knn.score(TRAIN_INPUT_DATA.values, TRAIN_TARGET_DATA.values.ravel())
        validation_accuracy = knn.score(VALID_INPUT_DATA.values, VALID_TARGET_DATA.values.ravel())

        print(f"{k} Nearest Neighbor training and validation mean accuracy are [{train_accuracy}] and [{validation_accuracy}]")

        accuracy_list.append(validation_accuracy)
        candidate_list.append(knn)

        train_error_list.append(1 - train_accuracy)
        validation_error_list.append(1 - validation_accuracy)

    best_knn = candidate_list[accuracy_list.index(max(accuracy_list))]

    # Calculate accuracy of the best KNN on the test data
    test_accuracy = best_knn.score(TEST_INPUT_DATA.values, TEST_TARGET_DATA.values.ravel())

    print(f"Best KNN is K=[{best_knn.get_params()['n_neighbors']}] with mean accuracy [{test_accuracy}] on the test data")


    plt.plot(KNN_K, train_error_list, label="training set error")
    plt.plot(KNN_K, validation_error_list, label="validation set error")
    plt.title('Error Rate vs. The Number of Nearest Neighbor')
    plt.xlabel('The Number of Nearest Neighbor (k)')
    plt.ylabel('Error Rate')
    plt.legend()
    plt.savefig("Question_E_KNN_Error.png", bbox_inches="tight", dpi=300, transparent=False)
    plt.show()

    return best_knn


def __main__():
    # Question 3 (a)
    global TRAIN_INPUT_DATA 
    global TRAIN_TARGET_DATA 
    global VALID_INPUT_DATA 
    global VALID_TARGET_DATA 
    global TEST_INPUT_DATA 
    global TEST_TARGET_DATA

    TRAIN_INPUT_DATA, TRAIN_TARGET_DATA, VALID_INPUT_DATA, VALID_TARGET_DATA, TEST_INPUT_DATA, TEST_TARGET_DATA = load_data()

    # Question 3 (b)
    BEST_TREE = select_tree_model()

    # Question 3 (d) Information Gain

    root_word = "donald"
    information_gain = compute_information_gain(root_word)
    print(f"Information gain of root word [{root_word}] is [{information_gain}]")

    root_word = "the"
    information_gain = compute_information_gain(root_word)
    print(f"Information gain of root word [{root_word}] is [{information_gain}]")

    root_word = "hillary"
    information_gain = compute_information_gain(root_word)
    print(f"Information gain of root word [{root_word}] is [{information_gain}]")

    root_word = "trump"
    information_gain = compute_information_gain(root_word)
    print(f"Information gain of root word [{root_word}] is [{information_gain}]")

    # Question 3 (e)
    select_knn_model()



__main__()
