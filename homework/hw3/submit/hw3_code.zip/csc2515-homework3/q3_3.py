"""
    Question 3.3
"""
from numpy.lib.function_base import disp
from data import load_all_data, get_digits_by_label
from q3_1 import KNearestNeighbor
from q3_2_SVM import SVMClassifier
from q3_2_MLP import NNClassifier
from q3_2_AdaBoost import AdaClassifier
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, roc_curve, accuracy_score, precision_score, recall_score, auc
import matplotlib.pyplot as plt
import numpy as np


def make_binary_classification_for_ROC(true_label, digit_class):
    true_label_temp = np.copy(true_label)
    # prediction_temp = np.copy(prediction)

    # The index of the array where the true label is this digit class
    index_is_class_true = np.where(true_label_temp == digit_class)
    # The index of the array where the true label is NOT this digit class
    index_not_class_true = np.where(true_label_temp != digit_class)
    # Make binary classification
    true_label_temp[index_is_class_true] = 1
    true_label_temp[index_not_class_true] = 0

    # # The index of the array where the prediction is this digit class
    # index_is_class_predict = np.where(prediction_temp == digit_class)
    # # The index of the array where the prediction is this digit class
    # index_not_class_predict = np.where(prediction_temp != digit_class)
    # # Make binary classification
    # prediction_temp[index_is_class_predict] = 1
    # prediction_temp[index_not_class_predict] = 0

    return true_label_temp



def get_roc_curve(true_label, predictions):
    print("ROC and AUC on test data:\n")

    fpr = {}
    tpr = {}
    roc_auc = {}
    for model in predictions:
        fpr[model] = {}
        tpr[model] = {}
        roc_auc[model] = {}

    # Iterate through 10 classes
    for digit_class in range(10):
        for model in predictions:
            true_label_temp = make_binary_classification_for_ROC(true_label, digit_class)
            fpr[model][digit_class], tpr[model][digit_class], _ = roc_curve(true_label_temp, predictions[model][:, digit_class])
            roc_auc[model][digit_class] = auc(fpr[model][digit_class], tpr[model][digit_class])

        plt.figure()
        lw = 2
        for model in predictions:
            plt.plot(
                fpr[model][digit_class],
                tpr[model][digit_class],
                lw=lw,
                label=f"{model} ROC curve (area = %0.2f)" % roc_auc[model][digit_class],
            )
        plt.plot([0, 1], [0, 1], color="black", lw=lw, linestyle="--")
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel("False Positive Rate")
        plt.ylabel("True Positive Rate")
        plt.title(f"ROC curve of digit {digit_class}")
        plt.legend(loc="lower right")
        # plt.show()
        plt.savefig(f"ROC curve of digit {digit_class}.png", bbox_inches="tight")



def main():
    # load data
    train_data, train_labels, test_data, test_labels = load_all_data('data') # (7000, 64), (7000,)

    # Question 3.2: Classifiers Comparison
    # knn
    print("Running KNN")
    knn = KNearestNeighbor(train_data, train_labels)
    best_k = 1
    print(f"The best k is [{best_k}] as we get from Q3.1")
    print("\n")
    
    # Question 3.2.1: design the best MLP classifier
    print("Running MLP")
    mlp = NNClassifier(train_data, train_labels)
    print(f"The optimal parameters for MLP classifier is: {mlp.train_and_return_best_param()}")
    print("\n")

    # # Question 3.2.2: design the best SVM classifier
    print("Running SVM")
    svc = SVMClassifier(train_data, train_labels)
    print(f"The optimal parameters for SVM classifier is: {svc.train_and_return_best_param()}")
    print("\n")

    # Question 3.2.3: design the best AdaBoost classifier
    print("Running AdaBoost")
    ada = AdaClassifier(train_data, train_labels)
    print(f"The optimal parameters for AdaBoost classifier is: {ada.train_and_return_best_param()}")
    print("\n")

    # Question 3.3 - Model Comparison
    # get the binary predictions from previous models
    knn_pred = knn.predict_use_sklearn_knn(test_data, best_k)
    mlp_pred = mlp.pred(test_data)
    svc_pred = svc.pred(test_data)
    ada_pred = ada.pred(test_data)

    # Get the probability predictions from previous models
    knn_pred_proba = knn.predict_probability_use_sklearn_knn(test_data, best_k)
    mlp_pred_proba = mlp.get_pred_proba(test_data)
    svc_pred_proba = svc.get_pred_proba(test_data)
    ada_pred_proba = ada.get_pred_proba(test_data)

    # Question 3.3.1 ROC (Receiver Operating Characteristics) curve
    predictions = {"KNN Classifier": knn_pred_proba, "MLP classifier": mlp_pred_proba, "SVM classifier": svc_pred_proba, "AdaBoost classifier": ada_pred_proba}
    get_roc_curve(test_labels, predictions)



    model_prediction_list = [(knn_pred, "KNN Classifier"), (mlp_pred, "MLP classifier"), (svc_pred, "SVM classifier"),  (ada_pred, "AdaBoost classifier")]
    # Question 3.3.2 Confusion Matrix
    for pred, model_name in model_prediction_list:
        print(f"The Confusion Matrix of {model_name} is:\n")
        cm = confusion_matrix(test_labels, pred)
        print(cm)

        plt.figure()
        display = ConfusionMatrixDisplay(confusion_matrix=cm)
        display.plot(cmap=plt.cm.Blues)
        display.ax_.set_title(f"The Confusion Matrix of {model_name}")
        plt.savefig(f"Confusion Matrix {model_name}.png", bbox_inches="tight")

        print("\n")

        

    # Question 3.3.3 Accuracy
    for pred, model_name in model_prediction_list:
        print(f"The Accuracy of {model_name} is: {accuracy_score(test_labels, pred)}")
    print("\n")



    # Question 3.3.4 Precision
    class_list = ["Digit 0", "Digit 1", "Digit 2", "Digit 3", "Digit 4", "Digit 5", "Digit 6", "Digit 7", "Digit 8", "Digit 9"]
    for pred, model_name in model_prediction_list:
        precision = precision_score(test_labels, pred, average = None)
        print(f"The Precision of {model_name} is:")
        # print(f"{precision}")
        
        for i, c in enumerate(class_list):
            print(f"The precision of class=[{c}] is [{precision[i]}].")
        
        print(f"The average precision across all classes is [{precision.mean()}].")
        print("\n")

   

    # Question 3.3.5 Recall
    for pred, model_name in model_prediction_list:
        recall = recall_score(test_labels, pred, average = None)
        print(f"The Recall of {model_name} is:")
        # print(f"{recall}")

        for i, c in enumerate(class_list):
            print(f"The recall of class=[{c}] is [{recall[i]}].")

        print(f"The average recall across all classes is [{recall.mean()}].")
        print("\n")

if __name__ == '__main__':
    main()