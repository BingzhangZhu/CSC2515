# csc2515-homework3

## Collaborators

Zhimao Lin, Bingzhang Zhu

## Development Environment

Operating System: macOS Big Sur Version 11.6.1 and above
Target processor: CPU (No GPU available)

## How to run the code

### Install all required packages

1. `cd csc2515-homework3`
2. `pip3 install -r requirements.txt`

### Q3(0)

`python3 ./q3_0.py`

### Q3(3.1)

`python3 ./q3_1.py`

### Q3(3.2 & 3.3)

`python3 ./q3_3.py`

## References
- https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html#sklearn.neighbors.KNeighborsClassifier.score
- https://numpy.org/doc/stable/reference/generated/numpy.reshape.html
- https://numpy.org/doc/stable/reference/generated/numpy.concatenate.html
- https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.imshow.html
- https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.KFold.html
- https://stackoverflow.com/questions/16817948/i-have-need-the-n-minimum-index-values-in-a-numpy-array
- https://www.geeksforgeeks.org/find-the-most-frequent-value-in-a-numpy-array/
- https://pythonprogramming.net/data-deep-learning-neural-network-pytorch/
- https://pythonprogramming.net/building-deep-learning-neural-network-pytorch/ 
- https://pythonprogramming.net/training-deep-learning-neural-network-pytorch/
- https://datascience.stackexchange.com/questions/45916/loading-own-train-data-and-labels-in-dataloader-using-pytorch
- https://www.vebuso.com/2020/03/svm-hyperparameter-tuning-using-gridsearchcv/
- https://scikit-learn.org/stable/modules/generated/sklearn.metrics.roc_curve.html?highlight=roc_curve#sklearn.metrics.roc_curve
- https://scikit-learn.org/stable/modules/generated/sklearn.neural_network.MLPClassifier.html
- https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.AdaBoostClassifier.html#sklearn.ensemble.AdaBoostClassifier
- https://scikit-learn.org/stable/modules/generated/sklearn.svm.SVC.html?highlight=svc#sklearn.svm.SVC
- https://scikit-learn.org/stable/auto_examples/model_selection/plot_roc.html#sphx-glr-auto-examples-model-selection-plot-roc-py
- https://en.wikipedia.org/wiki/Receiver_operating_characteristic#:~:text=A%20receiver%20operating%20characteristic%20curve,which%20led%20to%20its%20name.
- https://stackoverflow.com/questions/9535954/printing-lists-as-tabular-data