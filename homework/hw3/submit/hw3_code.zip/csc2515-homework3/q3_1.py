'''
Question 3.1 Skeleton Code

Here you should implement and evaluate the k-NN classifier.
'''

import data
import numpy as np
# Import pyplot - plt.imshow is useful!
import matplotlib.pyplot as plt

from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import KFold

class KNearestNeighbor(object):
    '''
    K Nearest Neighbor classifier
    '''

    def __init__(self, train_data, train_labels):
        self.train_data = train_data
        self.train_norm = (self.train_data**2).sum(axis=1).reshape(-1,1)
        self.train_labels = train_labels

    def l2_distance(self, test_point):
        '''
        Compute L2 distance between test point and each training point
        
        Input: test_point is a 1d numpy array
        Output: dist is a numpy array containing the distances between the test point and each training point
        '''
        # Process test point shape
        test_point = np.squeeze(test_point)
        if test_point.ndim == 1:
            test_point = test_point.reshape(1, -1)
        assert test_point.shape[1] == self.train_data.shape[1]

        # Compute squared distance
        test_norm = (test_point**2).sum(axis=1).reshape(1,-1)
        dist = self.train_norm + test_norm - 2*self.train_data.dot(test_point.transpose())
        return np.squeeze(dist)

    def query_knn(self, test_point, k):
        '''
        Query a single test point using the k-NN algorithm

        You should return the digit label provided by the algorithm
        '''

        distance = self.l2_distance(test_point)

        idx = np.argpartition(distance, k)[:k]
        candidates = self.train_labels[idx]
        digit = np.bincount(candidates.astype(int)).argmax()

        return digit

    def pred(self, test_data, k):
        knn_pred = []
        for test_point in test_data:
            prediction = self.query_knn(test_point, k)
            knn_pred.append(prediction)
        return knn_pred

    def predict_use_sklearn_knn(self, test_data, k):
        knn_model = KNeighborsClassifier(n_neighbors=k)
        knn_model.fit(self.train_data, self.train_labels)

        prediction = knn_model.predict(test_data)
        return prediction

    def predict_probability_use_sklearn_knn(self, test_data, k):
        knn_model = KNeighborsClassifier(n_neighbors=k)
        knn_model.fit(self.train_data, self.train_labels)

        prediction = knn_model.predict_proba(test_data)
        return prediction



def cross_validation(train_data, train_labels, k_range=np.arange(1,16)):
    '''
    Perform 10-fold cross validation to find the best value for k

    Note: Previously this function took knn as an argument instead of train_data,train_labels.
    The intention was for students to take the training data from the knn object - this should be clearer
    from the new function signature.
    '''
    aross_folds_validation_accuracy_list = []

    for k in k_range:
        print(f"Calculating K = [{k}] ...")

        # Loop over folds
        kf = KFold(n_splits=10, shuffle=True)

        validation_accuracy_list_of_each_k = []

        k_fold = 0
        for train_index, validation_index in kf.split(train_data):
            k_fold = k_fold + 1
            print(f"Calculating KFold = [{k_fold}] ...")
            # print(train_index)
            # print(validation_index)
            train_x = train_data[train_index]
            train_y = train_labels[train_index]

            validation_x = train_data[validation_index]
            validation_y = train_labels[validation_index]

            knn_model = KNeighborsClassifier(n_neighbors=k)
            knn_model.fit(train_x, train_y)

            validation_accuracy = knn_model.score(validation_x, validation_y)
            validation_accuracy_list_of_each_k.append(validation_accuracy)

        aross_folds_validation_accuracy_list.append(np.array(validation_accuracy_list_of_each_k).mean())

    # Evaluate k-NN
    average_accuracy_across_folds = max(aross_folds_validation_accuracy_list)
    best_k_index = aross_folds_validation_accuracy_list.index(average_accuracy_across_folds)
    best_k = k_range[best_k_index]

    return best_k, average_accuracy_across_folds

    

def classification_accuracy(knn, k, eval_data, eval_labels):
    '''
    Evaluate the classification accuracy of knn on the given 'eval_data'
    using the labels
    '''

    prediction_list = knn.pred(eval_data, k)

    prediction_list = np.array(prediction_list)
    accurate_count = (prediction_list == eval_labels).sum()
    accuracy = accurate_count / eval_labels.shape[0]

    return accuracy 



def show_image_result(test_vector):
    # Reshape the test vector
    test_image = test_vector.reshape((8,8))
    plt.imshow(test_image, cmap='gray')
    plt.show()



def main():
    train_data, train_labels, test_data, test_labels = data.load_all_data('data')
    knn = KNearestNeighbor(train_data, train_labels)

    # Example usage:
    predicted_label = knn.query_knn(test_data[0], 1)
    print(f"The predicted label of the example usage is [{predicted_label}].")
    # show_image_result(test_data[0])

    # Q3.1 (1)
    train_classification_accuracy_of_k1 = classification_accuracy(knn, 1, train_data, train_labels)
    test_classification_accuracy_of_k1 = classification_accuracy(knn, 1, test_data, test_labels)
    print(f"The train classification accuracy of [K = 1] is [{train_classification_accuracy_of_k1}].")
    print(f"The test classification accuracy of [K = 1] is [{test_classification_accuracy_of_k1}].")

    train_classification_accuracy_of_k15 = classification_accuracy(knn, 15, train_data, train_labels)
    test_classification_accuracy_of_k15 = classification_accuracy(knn, 15, test_data, test_labels)
    print(f"The train classification accuracy of [K = 15] is [{train_classification_accuracy_of_k15}].")
    print(f"The test classification accuracy of [K = 15] is [{test_classification_accuracy_of_k15}].")

    # Q3.1 (3)
    best_k, average_accuracy_across_folds = cross_validation(train_data, train_labels)
    
    # Re-train the model with the best K
    best_knn_model = KNeighborsClassifier(n_neighbors=best_k)
    best_knn_model.fit(train_data, train_labels)

    train_classification_accuracy = best_knn_model.score(train_data, train_labels)
    test_accuracy = best_knn_model.score(test_data, test_labels)

    print(f"The optimal K is [k = {best_k}]")
    print(f"The train classification accuracy is [{train_classification_accuracy}]")
    print(f"The average accuracy across folds is [{average_accuracy_across_folds}]")
    print(f"The test accuracy of the best K is [{test_accuracy}]")




if __name__ == '__main__':
    main()