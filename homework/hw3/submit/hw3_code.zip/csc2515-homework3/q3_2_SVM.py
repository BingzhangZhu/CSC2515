'''
    Question 3.2 Design an SVM classifier
'''

from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV

class SVMClassifier(object):

    def __init__(self, train_data, train_labels):
        self.train_data = train_data
        self.train_labels = train_labels
        self.svc = None

    def train_and_return_best_param(self):
        # set parameters
        params= {'kernel': ["rbf", "poly", "sigmoid"], 'gamma':[0.1, 0.01, 0.001], 'C':[100, 10, 1, 0.1, 0.01]}
        # params= {'kernel': ["rbf"], 'gamma':[0.1], 'C':[10]}
        self.svc = GridSearchCV(estimator = SVC(probability=True), param_grid = params, cv = 3)
        # find the best param set
        self.svc.fit(self.train_data, self.train_labels)
        return self.svc.best_params_
    
    def pred(self, test_data):
        pred = self.svc.predict(test_data)
        return pred

    def get_pred_proba(self, test_data):
        pred_proba = self.svc.predict_proba(test_data)
        return pred_proba



# def main():
    # load data
    # train_data, train_labels, test_data, test_labels = data.load_all_data('data') # (7000, 64), (7000,)

    # # set parameters
    # # params= {'kernel': ["rbf", "poly", "sigmoid"], 'gamma':[0.1, 0.01, 0.001], 'C':[100, 10, 1, 0.1, 0.01]}
    # params= {'kernel': ["rbf"], 'gamma':[0.1], 'C':[10]}
    # # find the best param set
    # grid = GridSearchCV(estimator=SVC(), param_grid = params, cv = 3)#5)
    # grid.fit(train_data, train_labels)
    # bestParam = grid.best_params_

    # # print the optimal param set
    # print("Best kernel is:", bestParam['kernel'])
    # print("Best gamma is:", bestParam['gamma'])
    # print("Best C is:", bestParam['C'])
    # print("/n")

    # # predict
    # pred = grid.predict(test_data)
    # get_performance(test_labels, pred)



if __name__ == '__main__':
    # main()
    pass