'''
    Question 3.2 Design an Neural Network Classifier with sk-learn
'''

from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import GridSearchCV

class NNClassifier(object):

    def __init__(self, train_data, train_labels):
        self.train_data = train_data
        self.train_labels = train_labels
        self.mlp = None

    def train_and_return_best_param(self):
        # set parameters
        params= {'hidden_layer_sizes': [(64, 64), (100, 100), (64, 64, 64, 64) (64, 64, 64)], 'activation':["logistic", "tanh", "relu"], 'learning_rate': ["constant", "invscaling", "adaptive"]}
        # params= {'hidden_layer_sizes': [(64, 64, 64)], 'activation':["tanh"], 'learning_rate': ["adaptive"]}
        self.mlp = GridSearchCV(estimator = MLPClassifier(), param_grid = params, cv = 3)
        # find the best param set
        self.mlp.fit(self.train_data, self.train_labels)
        return self.mlp.best_params_
    
    def pred(self, test_data):
        pred = self.mlp.predict(test_data)
        return pred

    def get_pred_proba(self, test_data):
        pred_proba = self.mlp.predict_proba(test_data)
        return pred_proba

if __name__ == '__main__':
    pass