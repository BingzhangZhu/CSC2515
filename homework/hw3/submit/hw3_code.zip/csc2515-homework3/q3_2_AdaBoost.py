'''
    Question 3.2 Design an Adaboost Classifier
'''

from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import GridSearchCV

class AdaClassifier(object):

    def __init__(self, train_data, train_labels):
        self.train_data = train_data
        self.train_labels = train_labels
        self.ada = None

    def train_and_return_best_param(self):
        # set parameters
        params= {"base_estimator__min_samples_leaf" : [2, 5], "base_estimator__max_depth": [5, 7], 'n_estimators': [50, 200, 300], 'learning_rate':[1, 0.1, 0.01, 0.001]}
        # v
        self.ada = GridSearchCV(estimator=AdaBoostClassifier(DecisionTreeClassifier()), param_grid = params, cv = 3)
        # find the best param set
        self.ada.fit(self.train_data, self.train_labels)
        return self.ada.best_params_
    
    def pred(self, test_data):
        pred = self.ada.predict(test_data)
        return pred

    def get_pred_proba(self, test_data):
        pred_proba = self.ada.predict_proba(test_data)
        return pred_proba

if __name__ == '__main__':
    pass