'''
    Question 3.2 Design an Neural Network Classifier with PyTorch
'''

import data
import numpy as np
# Import pyplot - plt.imshow is useful!
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

from torch.utils.data import DataLoader, TensorDataset
from torch import Tensor

# from sklearn.neighbors import KNeighborsClassifier
# from sklearn.model_selection import KFold

EPOCH = 10
BATCH_SIZE = 30

class NeuralNetwork(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(8*8, 64)
        self.fc2 = nn.Linear(64, 64)
        self.fc3 = nn.Linear(64, 64)
        self.fc4 = nn.Linear(64, 64)
        self.fc5 = nn.Linear(64, 10)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        x = F.relu(self.fc4(x))
        x = self.fc5(x)
        result = F.log_softmax(x, dim=1)
        return result



def show_image_result(test_vector):
    # Reshape the test vector
    test_image = test_vector.reshape((8,8))
    plt.imshow(test_image, cmap='gray')
    plt.show()



def calculate_accuracy(net, device, test_loader):
    correct = 0
    total = 0

    with torch.no_grad():
        for test_data in test_loader:
            X, y = test_data

            X = X.to(device)
            y = y.to(device)

            output = net(X.view(-1, 8*8).float())
            
            for idx, i in enumerate(output):
                if torch.argmax(i) == y[idx]:
                    correct += 1
                total += 1

    accuracy = correct / total
    print(f"The accuracy of this neural network is [{accuracy}].")
    return accuracy



def main():
    if torch.cuda.is_available():
        device = torch.device("cuda")
        print("Use GPU")
    else:
        device = torch.device("cpu") 
        print("Use CPU")

    train_data, train_labels, test_data, test_labels = data.load_all_data('data')

    train_set = TensorDataset(Tensor(train_data), Tensor(train_labels))
    test_set = TensorDataset(Tensor(test_data), Tensor(test_labels))
 
    train_loader = DataLoader(train_set, batch_size=BATCH_SIZE, shuffle=True)
    test_loader = DataLoader(test_set, batch_size=BATCH_SIZE, shuffle=True)

    neural_network = NeuralNetwork().to(device)
    print(neural_network)

    # loss_function = nn.CrossEntropyLoss()
    optimizer = optim.Adam(neural_network.parameters(), lr=0.001)

    for epoch in range(EPOCH):
        for train in train_loader:
            X, y = train
            X = X.to(device)
            y = y.to(device)
            neural_network.zero_grad()
            output = neural_network(X.view(-1, 8*8).float())
            loss = F.nll_loss(output, y.long())
            loss.backward()
            optimizer.step()
        print(f"The loss of epoch [{epoch}] is [{loss}].")

    accuracy = calculate_accuracy(neural_network, device, test_loader)
    





if __name__ == '__main__':
    main()
